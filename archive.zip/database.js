const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "memory.sqlite"));
db.pragma("journal_mode = WAL");

// Inisialisasi tabel chat_memory & global_knowledge
db.exec(`
  CREATE TABLE IF NOT EXISTS chat_memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    username TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    image_urls TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE INDEX IF NOT EXISTS idx_channel ON chat_memory(channel_id);

  CREATE TABLE IF NOT EXISTS global_knowledge (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content TEXT NOT NULL,
    username TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function saveMessage(channelId, userId, username, role, content, imageUrls = []) {
  const stmt = db.prepare(`
    INSERT INTO chat_memory (channel_id, user_id, username, role, content, image_urls)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  stmt.run(channelId, userId, username, role, content, JSON.stringify(imageUrls));
}

function getRecentMessages(channelId, limit = 15) {
  const stmt = db.prepare(`
    SELECT * FROM (
      SELECT id, channel_id, user_id, username, role, content, image_urls, timestamp 
      FROM chat_memory 
      WHERE channel_id = ? 
      ORDER BY id DESC 
      LIMIT ?
    ) ORDER BY id ASC
  `);
  return stmt.all(channelId, limit);
}

function clearMemory(channelId) {
  const stmt = db.prepare("DELETE FROM chat_memory WHERE channel_id = ?");
  return stmt.run(channelId);
}

// Fungsi untuk Memori Global Pembelajaran
function addGlobalKnowledge(content, username) {
  const stmt = db.prepare(`
    INSERT INTO global_knowledge (content, username)
    VALUES (?, ?)
  `);
  stmt.run(content, username);
}

function getAllGlobalKnowledge() {
  const stmt = db.prepare(`
    SELECT content FROM global_knowledge ORDER BY id ASC
  `);
  return stmt.all();
}

function clearGlobalKnowledge() {
  const stmt = db.prepare("DELETE FROM global_knowledge");
  return stmt.run();
}

module.exports = {
  saveMessage,
  getRecentMessages,
  clearMemory,
  addGlobalKnowledge,
  getAllGlobalKnowledge,
  clearGlobalKnowledge
};