require("dotenv").config();
const fs = require("fs");
const path = require("path");
const OpenAI = require("openai");
const { Client, GatewayIntentBits, Collection, Events } = require("discord.js");
const config = require("./config");
const { 
  saveMessage, 
  getRecentMessages, 
  addGlobalKnowledge, 
  getAllGlobalKnowledge 
} = require("./database");

const openai = new OpenAI({
  baseURL: process.env.AI_BASE_URL || "https://router.juan.web.id/v1",
  apiKey: process.env.AI_API_KEY
});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.commands = new Collection();
const commandFiles = fs.readdirSync(path.join(__dirname, "commands")).filter(file => file.endsWith(".js"));
for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  if (command.name) {
    client.commands.set(command.name, command);
  }
}

client.once(Events.ClientReady, (readyClient) => {
  console.log(`[READY] Bot CS AI & Global Learning aktif: ${readyClient.user.tag}`);
  
  if (config.activity) {
    readyClient.user.setPresence({
      activities: [{ name: config.activity.name, type: config.activity.type }],
      status: "online"
    });
  }
});

client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot) return;

  // 1. PROSES CHANNEL BELAJAR (KNOWLEDGE INGESTION)
  if (config.ai?.learningChannelId && message.channel.id === config.ai.learningChannelId) {
    const textContent = message.content.trim();
    if (!textContent) return;

    try {
      addGlobalKnowledge(textContent, message.author.username);
      await message.react("🧠"); // Beri reaksi otak tanda sudah dipelajari
      await message.reply(`✅ **Info baru tersimpan di otak bot!** Seluruh percakapan CS akan langsung mengingat dan menerapkan hal ini.`);
    } catch (err) {
      console.error("[LEARN ERROR]:", err);
      await message.reply("⚠️ Gagal menyimpan memori baru.");
    }
    return;
  }

  const isAllowedChannel = config.ai?.allowedChannels?.includes(message.channel.id);
  const isAllowedCategory = message.channel.parentId && config.ai?.allowedCategories?.includes(message.channel.parentId);

  // 2. ALUR CS DENGAN MEMORI CHANNEL + MEMORI GLOBAL DARI CHANNEL BELAJAR
  if (isAllowedChannel || isAllowedCategory) {
    const imageAttachments = message.attachments.filter(att => 
      att.contentType && att.contentType.startsWith("image/")
    );

    const textContent = message.content.trim();
    if (!textContent && imageAttachments.size === 0) return;

    const imageUrls = imageAttachments.map(att => att.url);

    try {
      await message.channel.sendTyping();

      // Simpan chat user saat ini ke database SQLite
      saveMessage(
        message.channel.id, 
        message.author.id, 
        message.author.username, 
        "user", 
        textContent || "[Kirim Gambar/Screenshot]", 
        imageUrls
      );

      // Ambil seluruh pengetahuan yang pernah diajarkan di channel belajar
      const globalKnowledgeRows = getAllGlobalKnowledge();
      let globalKnowledgeContext = "";
      if (globalKnowledgeRows.length > 0) {
        globalKnowledgeContext = "\n\n# CATATAN & ILMU TAMBAHAN DARI SERVER (WAJIB DITERAPKAN):\n" +
          globalKnowledgeRows.map((k, i) => `${i + 1}. ${k.content}`).join("\n");
      }

      // Gabungkan system prompt dasar dengan ilmu yang dipelajari
      const fullSystemPrompt = config.ai?.systemPrompt + globalKnowledgeContext;

      // Ambil histori obrolan di channel ini
      const historyLimit = config.ai?.historyLimit || 15;
      const dbHistory = getRecentMessages(message.channel.id, historyLimit);

      const conversationPayload = [
        { role: "system", content: fullSystemPrompt }
      ];

      for (const row of dbHistory) {
        const storedImages = row.image_urls ? JSON.parse(row.image_urls) : [];

        if (row.role === "assistant") {
          conversationPayload.push({
            role: "assistant",
            content: row.content
          });
        } else {
          if (storedImages.length > 0) {
            const contentArray = [
              { type: "text", text: `${row.username}: ${row.content}` }
            ];
            storedImages.forEach(url => {
              contentArray.push({ type: "image_url", image_url: { url } });
            });
            conversationPayload.push({ role: "user", content: contentArray });
          } else {
            conversationPayload.push({
              role: "user",
              content: `${row.username}: ${row.content}`
            });
          }
        }
      }

      const response = await openai.chat.completions.create({
        model: config.ai?.model || "deepseek-v4-flash",
        messages: conversationPayload
      });

      const replyText = response.choices[0]?.message?.content || "Maaf ngab, gak ada respon dari AI.";

      // Simpan balasan bot ke database
      saveMessage(message.channel.id, client.user.id, client.user.username, "assistant", replyText);

      if (replyText.length > 2000) {
        const chunks = replyText.match(/[\s\S]{1,1950}/g) || [];
        for (const chunk of chunks) {
          await message.reply(chunk);
        }
      } else {
        await message.reply(replyText);
      }
    } catch (error) {
      console.error("[CS AI ERROR]:", error);
      await message.reply("⚠️ Waduh ada kendala teknis pas proses AI-nya ngab, coba lagi nanti ya!");
    }
    return;
  }

  // 3. ALUR PERINTAH PREFIX
  if (!message.content.startsWith(config.prefix)) return;

  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  const command = client.commands.get(commandName);
  if (!command) return;

  try {
    await command.run(client, message, args, config);
  } catch (error) {
    console.error(`Error saat menjalankan ${commandName}:`, error);
    await message.reply("Terjadi kesalahan saat memproses perintah ini.");
  }
});

client.login(process.env.DISCORD_TOKEN);