module.exports = {
  name: "ping",
  description: "Mengecek respon dan latensi bot",
  run: async (client, message, args, config) => {
    const latency = client.ws.ping;
    await message.reply(`🏓 Pong! Latensi bot: **${latency}ms**`);
  }
};