const { clearMemory } = require("../database");

module.exports = {
  name: "resetmemory",
  description: "Menghapus ingatan/riwayat chat bot di channel ini",
  run: async (client, message, args, config) => {
    clearMemory(message.channel.id);
    await message.reply("🧹 **Memori percakapan di channel ini berhasil direset!** Bot sekarang mulai dari percakapan baru.");
  }
};